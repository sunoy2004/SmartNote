import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SummaryDisplayProps {
  summary: string;
}

export const SummaryDisplay = ({ summary }: SummaryDisplayProps) => {
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(summary);
    toast({
      title: 'Copied',
      description: 'Summary copied to clipboard',
    });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Summary</h3>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopy}
          className="gap-2"
        >
          <Copy className="h-4 w-4" />
          Copy
        </Button>
      </div>

      <div className="prose prose-sm max-w-none">
        <div className="p-4 bg-accent rounded-md text-sm space-y-2">
          {summary.split('\n').map((line, i) => (
            <p key={i} className="m-0">{line}</p>
          ))}
        </div>
      </div>
    </Card>
  );
};
