import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TranscriptDisplayProps {
  transcript: string;
  onSummarize: () => void;
  isLoading?: boolean;
}

export const TranscriptDisplay = ({ transcript, onSummarize, isLoading }: TranscriptDisplayProps) => {
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(transcript);
    toast({
      title: 'Copied',
      description: 'Transcript copied to clipboard',
    });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Transcript</h3>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopy}
          className="gap-2"
        >
          <Copy className="h-4 w-4" />
          Copy
        </Button>
      </div>

      <div className="prose prose-sm max-w-none mb-4">
        <div className="p-4 bg-muted rounded-md whitespace-pre-wrap text-sm">
          {transcript}
        </div>
      </div>

      <Button
        onClick={onSummarize}
        disabled={isLoading}
        className="w-full"
      >
        {isLoading ? 'Generating Summary...' : 'Generate Summary'}
      </Button>
    </Card>
  );
};
