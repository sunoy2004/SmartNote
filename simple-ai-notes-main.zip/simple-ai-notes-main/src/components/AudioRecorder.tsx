import { Mic, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useAudioRecorder } from '@/hooks/useAudioRecorder';
import { useToast } from '@/hooks/use-toast';

interface AudioRecorderProps {
  onAudioReady: (blob: Blob) => void;
}

export const AudioRecorder = ({ onAudioReady }: AudioRecorderProps) => {
  const { toast } = useToast();
  const {
    isRecording,
    recordingTime,
    audioBlob,
    startRecording,
    stopRecording,
    resetRecording,
  } = useAudioRecorder();

  const handleStart = async () => {
    try {
      await startRecording();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Could not access microphone. Please check permissions.',
        variant: 'destructive',
      });
    }
  };

  const handleStop = () => {
    stopRecording();
  };

  const handleTranscribe = () => {
    if (audioBlob) {
      onAudioReady(audioBlob);
      resetRecording();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="p-6">
      <div className="flex flex-col items-center gap-4">
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Record Audio</h3>
          <p className="text-sm text-muted-foreground">
            Click the microphone to start recording
          </p>
        </div>

        {isRecording && (
          <div className="text-3xl font-mono text-primary">
            {formatTime(recordingTime)}
          </div>
        )}

        <div className="flex gap-3">
          {!isRecording ? (
            <Button
              size="lg"
              onClick={handleStart}
              className="gap-2"
            >
              <Mic className="h-5 w-5" />
              Start Recording
            </Button>
          ) : (
            <Button
              size="lg"
              variant="destructive"
              onClick={handleStop}
              className="gap-2"
            >
              <Square className="h-5 w-5" />
              Stop Recording
            </Button>
          )}
        </div>

        {audioBlob && !isRecording && (
          <div className="w-full space-y-3">
            <audio
              controls
              src={URL.createObjectURL(audioBlob)}
              className="w-full"
            />
            <Button onClick={handleTranscribe} className="w-full">
              Transcribe Audio
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
};
