import { Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useRef, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface AudioUploaderProps {
  onAudioReady: (blob: Blob) => void;
}

export const AudioUploader = ({ onAudioReady }: AudioUploaderProps) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('audio/')) {
        toast({
          title: 'Invalid file',
          description: 'Please select an audio file',
          variant: 'destructive',
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      onAudioReady(selectedFile);
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <Card className="p-6">
      <div className="flex flex-col items-center gap-4">
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Upload Audio</h3>
          <p className="text-sm text-muted-foreground">
            Upload an audio file to transcribe
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="audio/*"
          onChange={handleFileSelect}
          className="hidden"
        />

        <Button
          size="lg"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          className="gap-2"
        >
          <Upload className="h-5 w-5" />
          Choose Audio File
        </Button>

        {selectedFile && (
          <div className="w-full space-y-3">
            <div className="p-3 bg-muted rounded-md text-sm">
              <p className="font-medium">{selectedFile.name}</p>
              <p className="text-muted-foreground">
                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
            <Button onClick={handleUpload} className="w-full">
              Transcribe File
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
};
