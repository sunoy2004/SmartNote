import { useState } from 'react';
import { AudioRecorder } from '@/components/AudioRecorder';
import { AudioUploader } from '@/components/AudioUploader';
import { TranscriptDisplay } from '@/components/TranscriptDisplay';
import { SummaryDisplay } from '@/components/SummaryDisplay';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

const mockTranscribe = (blob: Blob): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(
        "This is a mock transcript. In production, this would be the actual transcription of your audio. " +
        "The audio recorder is working correctly, capturing your voice and converting it to text using speech-to-text AI. " +
        "Once you connect to a backend with AI capabilities, this will show real transcriptions from your recordings."
      );
    }, 2000);
  });
};

const mockSummarize = (transcript: string): Promise<string> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(
        "📝 Key Points:\n\n" +
        "• This is a mock summary showing how the feature will work\n" +
        "• The summarizer will condense your transcript into concise notes\n" +
        "• Bullet points highlight the most important information\n" +
        "• Connect to backend AI to get real summarization\n\n" +
        "💡 Note: This mock summary demonstrates the UI. Real summaries will be much more useful!"
      );
    }, 1500);
  });
};

const Dashboard = () => {
  const { toast } = useToast();
  const [transcript, setTranscript] = useState<string>('');
  const [summary, setSummary] = useState<string>('');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);

  const handleAudioReady = async (blob: Blob) => {
    setIsTranscribing(true);
    setSummary('');
    
    try {
      const result = await mockTranscribe(blob);
      setTranscript(result);
      toast({
        title: 'Success',
        description: 'Audio transcribed successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to transcribe audio',
        variant: 'destructive',
      });
    } finally {
      setIsTranscribing(false);
    }
  };

  const handleSummarize = async () => {
    setIsSummarizing(true);
    
    try {
      const result = await mockSummarize(transcript);
      setSummary(result);
      toast({
        title: 'Success',
        description: 'Summary generated successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate summary',
        variant: 'destructive',
      });
    } finally {
      setIsSummarizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold">SmartNote AI</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-2">Create Transcript</h2>
            <p className="text-muted-foreground mb-6">
              Record audio or upload a file to get started
            </p>
          </div>

          <Tabs defaultValue="record" className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="record">Record</TabsTrigger>
              <TabsTrigger value="upload">Upload</TabsTrigger>
            </TabsList>
            <TabsContent value="record" className="mt-6">
              <AudioRecorder onAudioReady={handleAudioReady} />
            </TabsContent>
            <TabsContent value="upload" className="mt-6">
              <AudioUploader onAudioReady={handleAudioReady} />
            </TabsContent>
          </Tabs>

          {isTranscribing && (
            <div className="text-center py-8">
              <div className="animate-pulse text-primary">
                Transcribing audio...
              </div>
            </div>
          )}

          {transcript && !isTranscribing && (
            <TranscriptDisplay
              transcript={transcript}
              onSummarize={handleSummarize}
              isLoading={isSummarizing}
            />
          )}

          {summary && (
            <SummaryDisplay summary={summary} />
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
