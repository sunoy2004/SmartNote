// Update this page (the content is just a fallback if you fail to update the page)

import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Mic, FileText, Sparkles } from 'lucide-react';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">SmartNote AI</h1>
          <Button onClick={() => navigate('/login')} variant="outline">
            Sign In
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Transform Audio into Smart Notes
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Record or upload audio, get instant transcriptions, and generate AI-powered summaries
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={() => navigate('/dashboard')} className="gap-2">
              <Mic className="h-5 w-5" />
              Get Started
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate('/signup')} className="gap-2">
              Sign Up Free
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mt-16 text-left">
            <div className="space-y-3">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Mic className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Record or Upload</h3>
              <p className="text-muted-foreground">
                Capture audio directly or upload existing files in any format
              </p>
            </div>

            <div className="space-y-3">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Get Transcripts</h3>
              <p className="text-muted-foreground">
                AI-powered speech-to-text converts your audio to accurate text
              </p>
            </div>

            <div className="space-y-3">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Smart Summaries</h3>
              <p className="text-muted-foreground">
                Generate concise, actionable summaries from your transcripts
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
